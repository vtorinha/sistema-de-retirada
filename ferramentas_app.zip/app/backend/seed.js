import pkg from "pg";
const { Pool } = pkg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

async function seed() {
  await pool.query("INSERT INTO ferramentas (nome, quantidade_total, quantidade_disponivel) VALUES ($1,$2,$3)", ["Chave de Fenda", 10, 10]);
  await pool.query("INSERT INTO ferramentas (nome, quantidade_total, quantidade_disponivel) VALUES ($1,$2,$3)", ["Martelo", 5, 5]);
  await pool.query("INSERT INTO ferramentas (nome, quantidade_total, quantidade_disponivel) VALUES ($1,$2,$3)", ["Alicate", 8, 8]);
  console.log("Ferramentas iniciais adicionadas!");
  process.exit();
}

seed().catch(err => {
  console.error("Erro ao inserir dados:", err);
  process.exit(1);
});
