import express from "express";
import pkg from "pg";
import cors from "cors";

const { Pool } = pkg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

const app = express();
app.use(cors());
app.use(express.json());

// Criar tabelas
async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ferramentas (
      id SERIAL PRIMARY KEY,
      nome TEXT NOT NULL,
      quantidade_total INT NOT NULL,
      quantidade_disponivel INT NOT NULL
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS movimentacoes (
      id SERIAL PRIMARY KEY,
      ferramenta_id INT REFERENCES ferramentas(id),
      funcionario TEXT NOT NULL,
      status TEXT NOT NULL,
      data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);
}
initDb();

// Listar ferramentas
app.get("/ferramentas", async (req, res) => {
  const result = await pool.query("SELECT * FROM ferramentas ORDER BY id");
  res.json(result.rows);
});

// Registrar retirada
app.post("/retirada", async (req, res) => {
  const { ferramenta_id, funcionario } = req.body;
  await pool.query(
    "UPDATE ferramentas SET quantidade_disponivel = quantidade_disponivel - 1 WHERE id=$1 AND quantidade_disponivel > 0",
    [ferramenta_id]
  );
  await pool.query(
    "INSERT INTO movimentacoes (ferramenta_id, funcionario, status) VALUES ($1,$2,'EM USO')",
    [ferramenta_id, funcionario]
  );
  res.json({ message: "Ferramenta retirada" });
});

// Registrar devolução
app.post("/devolucao", async (req, res) => {
  const { ferramenta_id, funcionario } = req.body;
  await pool.query(
    "UPDATE ferramentas SET quantidade_disponivel = quantidade_disponivel + 1 WHERE id=$1",
    [ferramenta_id]
  );
  await pool.query(
    "INSERT INTO movimentacoes (ferramenta_id, funcionario, status) VALUES ($1,$2,'DEVOLVIDO')",
    [ferramenta_id, funcionario]
  );
  res.json({ message: "Ferramenta devolvida" });
});

// Histórico com JOIN (nome da ferramenta)
app.get("/movimentacoes", async (req, res) => {
  const result = await pool.query(`
    SELECT m.id, f.nome AS ferramenta_nome, m.funcionario, m.status, m.data_hora
    FROM movimentacoes m
    JOIN ferramentas f ON m.ferramenta_id = f.id
    ORDER BY m.data_hora DESC
  `);
  res.json(result.rows);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log("Servidor rodando na porta " + PORT));
