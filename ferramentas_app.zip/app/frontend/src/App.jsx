import { useEffect, useState } from "react";
import api from "./api";

function App() {
  const [ferramentas, setFerramentas] = useState([]);
  const [funcionario, setFuncionario] = useState("");
  const [movimentacoes, setMovimentacoes] = useState([]);
  const [tab, setTab] = useState("ferramentas");

  useEffect(() => {
    carregarFerramentas();
    carregarMovimentacoes();
  }, []);

  const carregarFerramentas = async () => {
    const res = await api.get("/ferramentas");
    setFerramentas(res.data);
  };

  const carregarMovimentacoes = async () => {
    const res = await api.get("/movimentacoes");
    setMovimentacoes(res.data);
  };

  const retirar = async (id) => {
    await api.post("/retirada", { ferramenta_id: id, funcionario });
    carregarFerramentas();
    carregarMovimentacoes();
  };

  const devolver = async (id) => {
    await api.post("/devolucao", { ferramenta_id: id, funcionario });
    carregarFerramentas();
    carregarMovimentacoes();
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Controle de Ferramentas</h1>

      <div style={{ marginBottom: "20px" }}>
        <button onClick={() => setTab("ferramentas")}>Ferramentas</button>
        <button onClick={() => setTab("historico")}>Histórico</button>
      </div>

      {tab === "ferramentas" && (
        <div>
          <input
            placeholder="Nome do funcionário"
            value={funcionario}
            onChange={(e) => setFuncionario(e.target.value)}
          />
          <table border="1" cellPadding="8" style={{ marginTop: "20px" }}>
            <thead>
              <tr>
                <th>Ferramenta</th>
                <th>Disponível</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {ferramentas.map((f) => (
                <tr key={f.id}>
                  <td>{f.nome}</td>
                  <td>{f.quantidade_disponivel}/{f.quantidade_total}</td>
                  <td>
                    <button onClick={() => retirar(f.id)}>Retirar</button>
                    <button onClick={() => devolver(f.id)}>Devolver</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "historico" && (
        <div>
          <h2>Histórico de Movimentações</h2>
          <table border="1" cellPadding="8" style={{ marginTop: "20px" }}>
            <thead>
              <tr>
                <th>ID</th>
                <th>Ferramenta</th>
                <th>Funcionário</th>
                <th>Status</th>
                <th>Data/Hora</th>
              </tr>
            </thead>
            <tbody>
              {movimentacoes.map((m) => (
                <tr key={m.id}>
                  <td>{m.id}</td>
                  <td>{m.ferramenta_nome}</td>
                  <td>{m.funcionario}</td>
                  <td>{m.status}</td>
                  <td>{new Date(m.data_hora).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default App;
